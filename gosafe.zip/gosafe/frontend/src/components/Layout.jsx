import { useState } from 'react';
import { NavLink, Link, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth.jsx';

export default function Layout() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  const item = (to, text) => (
    <NavLink to={to} onClick={close} className={({ isActive }) => (isActive ? 'active' : undefined)}>{text}</NavLink>
  );
  return (
    <>
      <a href="#main" className="skip">Skip to content</a>
      <header className="topbar">
        <Link to="/" className="brand" onClick={close}>🛡️ GoSafe</Link>
        <button className="menu-btn" aria-expanded={open} aria-controls="nav" onClick={() => setOpen(!open)}>Menu</button>
        <nav id="nav" className={open ? 'open' : ''} aria-label="Main">
          {item('/', 'Home')}
          {user && <>
            {item('/dashboard', 'Dashboard')}
            {item('/plan', 'Plan Route')}
            {item('/history', 'History')}
            {item('/facilities', 'Facilities')}
            <NavLink to="/emergency" onClick={close} className="sos-link">Emergency Mode</NavLink>
            {item('/profile', 'Profile')}
          </>}
          {item('/about', 'How it works')}
          {item('/upcoming', 'Upcoming')}
          {user
            ? <button className="link-btn" onClick={async () => { await logout(); close(); nav('/'); }}>Log out</button>
            : <>{item('/login', 'Log in')}{item('/register', 'Register')}</>}
        </nav>
      </header>
      <main id="main"><Outlet /></main>
      <footer className="footer">
        <p>GoSafe is a student prototype. It is not a replacement for official emergency services. In an emergency call your local emergency number (India: 112).</p>
        <p>Map data © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a> · Routing: OSRM demo · Weather: <a href="https://open-meteo.com/" target="_blank" rel="noopener noreferrer">Open-Meteo</a></p>
      </footer>
    </>
  );
}
