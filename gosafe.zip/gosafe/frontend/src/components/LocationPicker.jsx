import { useState } from 'react';
import { api } from '../api.js';

export default function LocationPicker({ id, label, value, onPick, allowGeo = false }) {
  const [q, setQ] = useState('');
  const [results, setResults] = useState([]);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');

  async function search() {
    if (q.trim().length < 2) return setMsg('Type at least 2 characters.');
    setBusy(true); setMsg(''); setResults([]);
    try {
      const d = await api(`/geocode?q=${encodeURIComponent(q.trim())}`);
      setResults(d.results);
      if (!d.results.length) setMsg('No places found. Try a more specific name.');
    } catch (e) { setMsg(e.message); } finally { setBusy(false); }
  }
  function geo() {
    if (!navigator.geolocation) return setMsg('Geolocation is not supported by this browser.');
    setMsg('Waiting for location permission…');
    navigator.geolocation.getCurrentPosition(
      (p) => { setMsg(''); onPick({ label: 'My current location', lat: p.coords.latitude, lon: p.coords.longitude }); },
      (e) => setMsg(e.code === 1 ? 'Location permission denied. Search for a place instead.' : 'Could not get your location.'),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }
  return (
    <fieldset className="picker">
      <legend>{label}</legend>
      {value && <p className="picked" aria-live="polite">✔ {value.label}</p>}
      <div className="row">
        <label htmlFor={id} className="sr">{label} search</label>
        <input id={id} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search a place or address"
          onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); search(); } }} />
        <button type="button" onClick={search} disabled={busy}>{busy ? 'Searching…' : 'Search'}</button>
        {allowGeo && <button type="button" className="secondary" onClick={geo}>Use my location</button>}
      </div>
      {msg && <p className="note" role="status">{msg}</p>}
      {results.length > 0 && (
        <ul className="results">
          {results.map((r, i) => (
            <li key={i}><button type="button" className="link-btn" onClick={() => { onPick(r); setResults([]); setQ(''); }}>{r.label}</button></li>
          ))}
        </ul>
      )}
    </fieldset>
  );
}
