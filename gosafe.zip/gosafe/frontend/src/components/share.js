// User-initiated sharing only: opens the phone's share sheet or copies text. Nothing is sent automatically.
export async function shareText(title, text) {
  try {
    if (navigator.share) { await navigator.share({ title, text }); return 'Share sheet opened.'; }
    await navigator.clipboard.writeText(text);
    return 'Copied to clipboard. Paste it into a message.';
  } catch (e) {
    return e.name === 'AbortError' ? '' : 'Could not share automatically. Please copy the text manually.';
  }
}
export const osmLink = (lat, lon) => `https://www.openstreetmap.org/?mlat=${lat}&mlon=${lon}#map=16/${lat}/${lon}`;
