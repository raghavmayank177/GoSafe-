import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import MapView, { Legend, FAC_LABELS } from './MapView.jsx';
import { Badge, provBadge } from './Badge.jsx';

const km = (a, b) => {
  const r = (d) => (d * Math.PI) / 180;
  const h = Math.sin(r(b.lat - a.lat) / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(r(b.lon - a.lon) / 2) ** 2;
  return 2 * 6371 * Math.asin(Math.sqrt(h));
};
const CATS = ['hospital', 'police', 'ambulance_station', 'fuel', 'rest_area'];

export default function FacilitiesPanel({ location, withRouteLinks = false }) {
  const [data, setData] = useState(null);
  const [err, setErr] = useState('');
  const [loading, setLoading] = useState(false);
  const [cat, setCat] = useState('hospital');

  useEffect(() => {
    if (!location) return;
    setLoading(true); setErr(''); setData(null);
    api(`/facilities?lat=${location.lat}&lon=${location.lon}&radius=10000`)
      .then(setData).catch((e) => setErr(e.message)).finally(() => setLoading(false));
  }, [location]);

  const list = useMemo(() => {
    if (!data) return [];
    return data.facilities.map((f) => ({ ...f, km: km(location, f) })).filter((f) => f.category === cat).sort((a, b) => a.km - b.km).slice(0, 10);
  }, [data, cat, location]);

  if (!location) return <p className="note">Choose a location above to see nearby facilities.</p>;
  return (
    <section aria-labelledby="fac-h">
      <h2 id="fac-h">Nearby facilities <Badge text={err ? 'DATA UNAVAILABLE' : provBadge(data?.provenance)} /></h2>
      <div className="chips" role="group" aria-label="Facility type">
        {CATS.map((c) => <button key={c} type="button" aria-pressed={cat === c} className={cat === c ? 'chip on' : 'chip'} onClick={() => setCat(c)}>{FAC_LABELS[c]}</button>)}
      </div>
      {loading && <p role="status">Loading facilities from OpenStreetMap…</p>}
      {err && <p className="error" role="alert">{err} The rest of GoSafe still works.</p>}
      {data && (
        <>
          <MapView facilities={list} center={location} height={300} />
          <Legend facilities />
          {list.length === 0
            ? <p className="note">No {FAC_LABELS[cat].toLowerCase()} mapped within 10 km. OpenStreetMap may be incomplete here; this does not prove none exist.</p>
            : <ol className="fac-list">{list.map((f) => (
                <li key={f.id}>
                  <strong>{f.name || `Unnamed ${FAC_LABELS[cat].toLowerCase()}`}</strong> — {f.km.toFixed(1)} km straight-line
                  {withRouteLinks && <> · <Link to={`/plan?fromLat=${location.lat}&fromLon=${location.lon}&fromName=${encodeURIComponent(location.label)}&toLat=${f.lat}&toLon=${f.lon}&toName=${encodeURIComponent(f.name || FAC_LABELS[cat])}`}>Compare routes here</Link></>}
                </li>))}</ol>}
          <p className="note small">Source: {data.provenance.provider} · fetched {new Date(data.provenance.fetchedAt).toLocaleTimeString()} · {data.provenance.attribution}. {data.provenance.note}</p>
        </>
      )}
    </section>
  );
}
