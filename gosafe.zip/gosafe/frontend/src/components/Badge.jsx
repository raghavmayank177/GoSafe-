const STYLES = {
  'PROTOTYPE ESTIMATE': 'warn', 'INSUFFICIENT DATA': 'bad', 'DATA UNAVAILABLE': 'bad', ESTIMATE: 'info',
  FORECAST: 'info', 'OSM COMMUNITY DATA': 'info', 'DEMO / SIMULATED': 'warn', UPCOMING: 'muted', 'NO LIVE TRAFFIC': 'muted',
};
export const Badge = ({ text }) => <span className={`badge ${STYLES[text] || 'muted'}`}>{text}</span>;

// Map a provenance record from the API to an honest badge label.
export function provBadge(p) {
  if (!p || p.status === 'unavailable') return 'DATA UNAVAILABLE';
  if (p.kind === 'forecast') return 'FORECAST';
  if (p.kind === 'estimated') return 'ESTIMATE';
  if (p.kind === 'observed') return 'OSM COMMUNITY DATA';
  return 'ESTIMATE';
}
