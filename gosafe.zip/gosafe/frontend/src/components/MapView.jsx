import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

export const ROUTE_COLORS = ['#1d6fdc', '#e07b00', '#7a3fc4', '#2a9d5c'];
export const COVER_COLORS = { near: '#2a9d5c', moderate: '#f4a000', far: '#d62828' };
export const FAC_COLORS = { hospital: '#d62828', police: '#1d3557', fuel: '#e9a100', rest_area: '#2a9d5c', ambulance_station: '#b5179e', other: '#666' };
export const FAC_LABELS = { hospital: 'Hospital', police: 'Police station', fuel: 'Petrol station', rest_area: 'Rest area', ambulance_station: 'Ambulance station' };

export default function MapView({ routes = [], selected = 0, origin, destination, facilities = [], coverage = null, center, height = 420 }) {
  const el = useRef(null);
  const map = useRef(null);
  const layer = useRef(null);

  useEffect(() => {
    map.current = L.map(el.current, { scrollWheelZoom: false }).setView([20.6, 78.9], 5);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    }).addTo(map.current);
    layer.current = L.layerGroup().addTo(map.current);
    return () => map.current.remove();
  }, []);

  useEffect(() => {
    const g = layer.current;
    g.clearLayers();
    const bounds = [];
    routes.forEach((r, i) => {
      const pts = r.coordinates.map(([lon, lat]) => [lat, lon]);
      const isSel = i === selected;
      L.polyline(pts, { color: ROUTE_COLORS[i % 4], weight: isSel ? 7 : 4, opacity: isSel ? 0.95 : 0.5 }).addTo(g);
      pts.forEach((p) => bounds.push(p));
    });
    [[origin, 'Start'], [destination, 'Destination']].forEach(([p, t]) => {
      if (p) {
        L.circleMarker([p.lat, p.lon], { radius: 9, color: '#111', weight: 2, fillColor: t === 'Start' ? '#2a9d5c' : '#d62828', fillOpacity: 1 })
          .bindTooltip(`${t}: ${p.label}`).addTo(g);
        bounds.push([p.lat, p.lon]);
      }
    });
    facilities.forEach((f) => {
      L.circleMarker([f.lat, f.lon], { radius: 6, color: '#fff', weight: 1, fillColor: FAC_COLORS[f.category] || '#666', fillOpacity: 0.95 })
        .bindTooltip(`${FAC_LABELS[f.category] || 'Place'}: ${f.name || 'unnamed'}`).addTo(g);
      bounds.push([f.lat, f.lon]);
    });
    (coverage || []).forEach((c) => {
      L.circleMarker([c.lat, c.lon], { radius: 7, color: '#fff', weight: 2, fillColor: COVER_COLORS[c.level], fillOpacity: 1 })
        .bindTooltip(`Nearest mapped hospital: ${c.nearestHospitalKm} km`).addTo(g);
    });
    if (center) L.circleMarker([center.lat, center.lon], { radius: 8, color: '#000', fillColor: '#00a6ff', fillOpacity: 1 }).bindTooltip('Your selected location').addTo(g);
    if (bounds.length) map.current.fitBounds(bounds, { padding: [30, 30], maxZoom: 15 });
    else if (center) map.current.setView([center.lat, center.lon], 13);
  }, [routes, selected, origin, destination, facilities, coverage, center]);

  return <div ref={el} className="map" style={{ height }} role="region" aria-label="Interactive map" />;
}

export function Legend({ routes = false, facilities = false }) {
  return (
    <ul className="legend" aria-label="Map legend">
      {routes && <><li><i style={{ background: '#2a9d5c' }} />Start</li><li><i style={{ background: '#d62828' }} />Destination</li>
        <li><i style={{ background: ROUTE_COLORS[0], height: 4 }} />Route 1</li><li><i style={{ background: ROUTE_COLORS[1], height: 4 }} />Route 2</li><li><i style={{ background: ROUTE_COLORS[2], height: 4 }} />Route 3</li></>}
      {facilities && Object.entries(FAC_LABELS).map(([k, v]) => <li key={k}><i style={{ background: FAC_COLORS[k] }} />{v}</li>)}
    </ul>
  );
}
