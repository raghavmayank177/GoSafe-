import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../auth.jsx';

export default function Profile() {
  const { user, setUser } = useAuth();
  const [name, setName] = useState(user.name);
  const [msg, setMsg] = useState('');
  async function save(e) {
    e.preventDefault(); setMsg('');
    try { setUser((await api('/profile', { method: 'PATCH', body: { name } })).user); setMsg('Saved.'); }
    catch (e2) { setMsg(e2.details?.[0]?.message || e2.message); }
  }
  return (
    <div className="page narrow">
      <h1>Profile</h1>
      <p>Email: <strong>{user.email}</strong><br /><small>Member since {new Date(user.createdAt + 'Z').toLocaleDateString()}</small></p>
      <form onSubmit={save}>
        <label htmlFor="pn">Display name</label>
        <input id="pn" value={name} onChange={(e) => setName(e.target.value)} />
        <button type="submit">Save</button>
        {msg && <p role="status">{msg}</p>}
      </form>
      <p><Link to="/history">Saved &amp; recent routes</Link> · <Link to="/emergency">Trusted contacts</Link></p>
    </div>
  );
}
