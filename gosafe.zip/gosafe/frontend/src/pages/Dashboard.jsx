import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../auth.jsx';

export default function Dashboard() {
  const { user } = useAuth();
  const [routes, setRoutes] = useState(null);
  const [err, setErr] = useState('');
  useEffect(() => { api('/routes').then((d) => setRoutes(d.routes)).catch((e) => setErr(e.message)); }, []);
  const last = routes?.[0];
  return (
    <div className="page">
      <h1>Welcome, {user.name}</h1>
      <div className="grid">
        <article className="card"><h2>Plan a safe route</h2><p>Compare alternatives with an explainable prototype safety score.</p><Link className="btn" to="/plan">Plan Route</Link></article>
        <article className="card sos"><h2>Emergency Mode</h2><p>Emergency numbers, trusted contacts, nearby hospitals and police.</p><Link className="btn danger" to="/emergency">Open Emergency Mode</Link></article>
        <article className="card"><h2>Last route searched</h2>
          {err && <p className="error" role="alert">{err}</p>}
          {!routes && !err && <p role="status">Loading…</p>}
          {routes && !last && <p>No searches yet. Plan your first route.</p>}
          {last && <p><Link to={`/routes/${last.id}`}>{last.origin.split(',')[0]} → {last.destination.split(',')[0]}</Link><br /><small>{new Date(last.createdAt + 'Z').toLocaleString()}</small></p>}
          <Link to="/history">All history</Link>
        </article>
      </div>
      <p className="note">Presenting soon? Run the <Link to="/status">system check</Link> first.</p>
    </div>
  );
}
