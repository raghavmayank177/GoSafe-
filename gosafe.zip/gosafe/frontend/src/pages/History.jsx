import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';

export default function History() {
  const [tab, setTab] = useState('all');
  const [routes, setRoutes] = useState(null);
  const [err, setErr] = useState('');
  const load = () => api(`/routes${tab === 'saved' ? '?saved=1' : ''}`).then((d) => setRoutes(d.routes)).catch((e) => setErr(e.message));
  useEffect(() => { setRoutes(null); setErr(''); load(); }, [tab]); // eslint-disable-line
  const del = async (id) => { if (confirm('Delete this route?')) { await api(`/routes/${id}`, { method: 'DELETE' }); load(); } };
  return (
    <div className="page">
      <h1>Saved &amp; Recent Routes</h1>
      <div className="chips" role="group" aria-label="Filter">
        <button className={tab === 'all' ? 'chip on' : 'chip'} aria-pressed={tab === 'all'} onClick={() => setTab('all')}>Recent</button>
        <button className={tab === 'saved' ? 'chip on' : 'chip'} aria-pressed={tab === 'saved'} onClick={() => setTab('saved')}>Saved</button>
      </div>
      {err && <p className="error" role="alert">{err}</p>}
      {!routes && !err && <p role="status">Loading…</p>}
      {routes?.length === 0 && <p>{tab === 'saved' ? 'No saved routes yet.' : 'No routes yet.'} <Link to="/plan">Plan a route</Link></p>}
      <ul className="hist">
        {routes?.map((r) => (
          <li key={r.id}>
            <Link to={`/routes/${r.id}`}>{r.origin.split(',')[0]} → {r.destination.split(',')[0]}</Link> {r.saved && '★'}
            <small> {new Date(r.createdAt + 'Z').toLocaleString()}</small>
            <button className="link-btn" onClick={() => del(r.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
