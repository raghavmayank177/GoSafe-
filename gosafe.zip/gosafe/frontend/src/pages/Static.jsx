import { Link } from 'react-router-dom';
import { Badge } from '../components/Badge.jsx';

const STATUS = [
  ['Register / login / history / saved routes', 'Implemented', 'SQLite, hashed passwords, HttpOnly cookie'],
  ['Route alternatives + map', 'Implemented', 'OSRM public demo server (no live traffic), OpenStreetMap tiles'],
  ['Place search', 'Implemented', 'Nominatim (OpenStreetMap)'],
  ['Safety score', 'Partially implemented', 'Prototype estimate from hospital proximity + origin weather only'],
  ['Weather advisory', 'Partially implemented', 'Open-Meteo at the origin point only'],
  ['Nearby hospitals / police / fuel / rest areas', 'Partially implemented', 'OpenStreetMap via Overpass; community data, may be incomplete'],
  ['Hospital-coverage strip, quick comparison, trip brief sharing', 'Implemented', 'Derived from OpenStreetMap hospitals; you choose where to share'],
  ['System check before demo', 'Implemented', 'Tests each external service'],
  ['Trusted contacts', 'Implemented', 'Stored per user; you tap to call'],
  ['Ambulance-style route comparison', 'Partially implemented', 'Time-ordered routing estimate only; no priority access'],
  ['Accident hotspots, live traffic, road conditions', 'Upcoming', 'Need verified datasets or authorised providers'],
  ['SOS messaging / automatic calling', 'Upcoming', 'Not implemented; never simulated'],
];

export function About() {
  return (
    <div className="page">
      <h1>How GoSafe works</h1>
      <ol>
        <li><strong>Search</strong> a start and destination (Nominatim).</li>
        <li><strong>Routes</strong> and alternatives come from OSRM. That is road geometry and a free-flow time estimate, not safety data.</li>
        <li><strong>Safety evidence</strong> is added only where a source exists: hospitals mapped in OpenStreetMap near the route, and weather at the start point.</li>
        <li><strong>Score</strong>: 60% emergency-service access, 40% weather (renormalised if one is missing, shown as "INSUFFICIENT DATA" without hospital data). The weights are prototype assumptions, not validated safety science. The score is rounded to the nearest 5.</li>
      </ol>
      <h2>Feature status</h2>
      <table>
        <thead><tr><th>Feature</th><th>Status</th><th>Detail</th></tr></thead>
        <tbody>{STATUS.map(([a, b, c]) => <tr key={a}><td>{a}</td><td>{b === 'Upcoming' ? <Badge text="UPCOMING" /> : b}</td><td>{c}</td></tr>)}</tbody>
      </table>
      <p>See the <Link to="/upcoming">roadmap</Link>.</p>
    </div>
  );
}

const ROADMAP = [
  ['Verified accident hotspots', 'Requires API/Verified Dataset', 'An official or open accident dataset (e.g. government road-accident data) with licence, coverage and a spatial join to route geometry.'],
  ['Authorised live traffic', 'Requires API/Verified Dataset', 'A licensed traffic provider and API key stored on the server.'],
  ['Road closures', 'Requires API/Verified Dataset', 'Authorised closure feed with timestamps and expiry.'],
  ['Road-condition reporting', 'Planned', 'Moderated user reports, a reports table, abuse controls and verification workflow.'],
  ['Route-wide weather sampling', 'In Development', 'Sample weather at several points along each route and aggregate honestly.'],
  ['Verified hospital / fuel / rest-stop data', 'Research Needed', 'Cross-check OSM against official facility registers; add phone/hours only when verified.'],
  ['Ambulance-oriented routing', 'Research Needed', 'Authorised emergency-vehicle routing data and coordination with a dispatch authority.'],
  ['SOS / location sharing', 'Planned', 'Tested SMS/WhatsApp provider integration with explicit user confirmation.'],
  ['Voice navigation', 'Future Release', 'Turn-by-turn steps from the router plus speech synthesis.'],
  ['Multilingual UI', 'Planned', 'i18n framework and translated strings (e.g. Hindi).'],
  ['PWA / offline support', 'Future Release', 'Service worker, manifest, cached contacts and emergency info.'],
  ['Analytics and admin data tools', 'Future Release', 'Admin role, dataset import tools, privacy-respecting analytics.'],
];

export function Upcoming() {
  return (
    <div className="page">
      <h1>Upcoming features</h1>
      <p>None of these work yet. Each lists what is needed to build it.</p>
      <div className="grid">
        {ROADMAP.map(([t, s, n]) => <article className="card" key={t}><h3>{t}</h3><Badge text="UPCOMING" /> <span className="tag">{s}</span><p>{n}</p></article>)}
      </div>
    </div>
  );
}

export function NotFound() {
  return <div className="page center"><h1>404 – Page not found</h1><p>That page does not exist.</p><Link className="btn" to="/">Go home</Link></div>;
}
