import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../api.js';
import LocationPicker from '../components/LocationPicker.jsx';

function fromParams(sp, p, defLabel) {
  const lat = parseFloat(sp.get(`${p}Lat`)), lon = parseFloat(sp.get(`${p}Lon`));
  return Number.isFinite(lat) && Number.isFinite(lon) ? { lat, lon, label: sp.get(`${p}Name`) || defLabel } : null;
}

const SAMPLES = [
  ['New Delhi → Agra', { label: 'New Delhi', lat: 28.6139, lon: 77.209 }, { label: 'Agra', lat: 27.1767, lon: 78.0081 }],
  ['Mumbai → Pune', { label: 'Mumbai', lat: 19.076, lon: 72.8777 }, { label: 'Pune', lat: 18.5204, lon: 73.8567 }],
];

export default function PlanRoute() {
  const [sp] = useSearchParams();
  const nav = useNavigate();
  const [origin, setOrigin] = useState(() => fromParams(sp, 'from', 'Start'));
  const [dest, setDest] = useState(() => fromParams(sp, 'to', 'Destination'));
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  async function go(e) {
    e.preventDefault();
    setErr(''); setBusy(true);
    try {
      const r = await api('/routes/plan', { method: 'POST', body: { origin, destination: dest } });
      nav(`/routes/${r.id}`);
    } catch (e2) { setErr(e2.message); } finally { setBusy(false); }
  }
  return (
    <div className="page">
      <h1>Plan Route</h1>
      <p>Pick a start and destination. GoSafe asks the routing service for alternatives, then adds the safety information it can find.</p>
      <div className="row" aria-label="Sample journeys">
        <span className="note small">Try a sample journey (real places, live data):</span>
        {SAMPLES.map(([t, a, b]) => <button key={t} type="button" className="chip" onClick={() => { setOrigin(a); setDest(b); }}>{t}</button>)}
      </div>
      <form onSubmit={go}>
        <LocationPicker id="from" label="Start" value={origin} onPick={setOrigin} allowGeo />
        <LocationPicker id="to" label="Destination" value={dest} onPick={setDest} />
        {err && <p className="error" role="alert">{err}</p>}
        <button type="submit" disabled={!origin || !dest || busy}>{busy ? 'Finding routes…' : 'Compare routes'}</button>
        {(!origin || !dest) && <p className="note small">Choose both a start and a destination from the search results.</p>}
      </form>
    </div>
  );
}
