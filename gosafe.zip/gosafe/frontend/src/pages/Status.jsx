import { useState } from 'react';
import { api } from '../api.js';
import { Badge } from '../components/Badge.jsx';

export default function Status() {
  const [data, setData] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  async function run() {
    setBusy(true); setErr('');
    try { setData(await api('/status')); } catch (e) { setErr(e.message); } finally { setBusy(false); }
  }
  return (
    <div className="page">
      <h1>System check</h1>
      <p>Run this a few minutes before presenting. It tests each external service GoSafe depends on. If one fails, that feature shows "DATA UNAVAILABLE" but the rest of the app keeps working.</p>
      <button onClick={run} disabled={busy}>{busy ? 'Checking…' : 'Run check'}</button>
      {err && <p className="error" role="alert">{err}</p>}
      {data && (
        <table>
          <thead><tr><th>Service</th><th>Result</th><th>Time</th></tr></thead>
          <tbody>{data.providers.map((p) => (
            <tr key={p.name}><td>{p.name}</td><td>{p.ok ? <Badge text="ESTIMATE" /> : <Badge text="DATA UNAVAILABLE" />} {p.ok ? 'reachable' : p.error}</td><td>{p.ms} ms</td></tr>
          ))}</tbody>
        </table>
      )}
      {data && <p className="note small">Checked {new Date(data.checkedAt).toLocaleTimeString()}. Limited to 6 checks per minute.</p>}
    </div>
  );
}
