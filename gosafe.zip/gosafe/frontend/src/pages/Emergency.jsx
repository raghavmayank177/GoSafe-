import { useEffect, useState } from 'react';
import { api } from '../api.js';
import LocationPicker from '../components/LocationPicker.jsx';
import FacilitiesPanel from '../components/FacilitiesPanel.jsx';
import { Badge } from '../components/Badge.jsx';
import { shareText, osmLink } from '../components/share.js';

export default function Emergency() {
  const [loc, setLoc] = useState(null);
  const [contacts, setContacts] = useState([]);
  const [f, setF] = useState({ name: '', phone: '' });
  const [err, setErr] = useState('');
  const [shareMsg, setShareMsg] = useState('');
  const load = () => api('/contacts').then((d) => setContacts(d.contacts)).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, []);

  async function add(e) {
    e.preventDefault(); setErr('');
    try { await api('/contacts', { method: 'POST', body: f }); setF({ name: '', phone: '' }); load(); }
    catch (e2) { setErr(e2.details?.[0]?.message || e2.message); }
  }
  const del = async (id) => { await api(`/contacts/${id}`, { method: 'DELETE' }); load(); };

  return (
    <div className="page">
      <h1>Emergency Mode</h1>
      <div className="alert-box" role="alert">
        <strong>This prototype is not a replacement for official emergency services.</strong> It cannot call, message or dispatch police or ambulances. In an emergency, call your local emergency number.
        <div className="row"><a className="btn danger" href="tel:112">Call 112 (India)</a><span className="note small">Opens your phone dialler; you must confirm the call.</span></div>
      </div>

      <section aria-labelledby="loc-h">
        <h2 id="loc-h">Your location</h2>
        <LocationPicker id="em-loc" label="Where are you?" value={loc} onPick={setLoc} allowGeo />
        {loc && <p>Coordinates: {loc.lat.toFixed(5)}, {loc.lon.toFixed(5)} · <a href={`https://www.openstreetmap.org/?mlat=${loc.lat}&mlon=${loc.lon}#map=16/${loc.lat}/${loc.lon}`} target="_blank" rel="noopener noreferrer">Open on OpenStreetMap</a></p>}
        {loc && <div className="row"><button onClick={async () => setShareMsg(await shareText('My location', `My location: ${loc.lat.toFixed(5)}, ${loc.lon.toFixed(5)} ${osmLink(loc.lat, loc.lon)}`))}>Share my location</button>{shareMsg && <span role="status" className="note small">{shareMsg}</span>}</div>}
        <p className="note small">You choose the app and the person: GoSafe only opens your share sheet or copies the text. Automatic SOS messaging <Badge text="UPCOMING" /></p>
      </section>

      <section aria-labelledby="tc-h">
        <h2 id="tc-h">Trusted contacts</h2>
        {contacts.length === 0 && <p>No contacts yet. Add up to 5.</p>}
        <ul className="hist">{contacts.map((c) => (
          <li key={c.id}>{c.name} — <a href={`tel:${c.phone.replace(/[^\d+]/g, '')}`}>{c.phone}</a> <button className="link-btn" onClick={() => del(c.id)}>Remove</button></li>
        ))}</ul>
        <form onSubmit={add} className="row">
          <label className="sr" htmlFor="cn">Contact name</label><input id="cn" placeholder="Name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required />
          <label className="sr" htmlFor="cp">Phone number</label><input id="cp" placeholder="Phone e.g. +91 98765 43210" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} required />
          <button type="submit">Add contact</button>
        </form>
        {err && <p className="error" role="alert">{err}</p>}
      </section>

      <FacilitiesPanel location={loc} withRouteLinks />
      <p className="note">"Compare routes here" lists routes ordered by estimated time to the chosen hospital or police station. This is a plain routing comparison <Badge text="ESTIMATE" />, not ambulance-priority routing, which needs an authorised service.</p>
    </div>
  );
}
