import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '../api.js';
import MapView, { Legend, ROUTE_COLORS, COVER_COLORS } from '../components/MapView.jsx';
import { shareText, osmLink } from '../components/share.js';
import { Badge, provBadge } from '../components/Badge.jsx';

function verdict(routes) {
  if (routes.length < 2) return 'Only one route was found, so there is no trade-off to compare.';
  const fastest = routes.reduce((a, b) => (b.durationMin < a.durationMin ? b : a));
  const scored = routes.filter((r) => r.safety.score != null);
  if (!scored.length) return 'There is not enough data to compare safety, so compare time and distance only.';
  const best = scored.reduce((a, b) => (b.safety.score > a.safety.score ? b : a));
  if (best.index === fastest.index || best.safety.score === fastest.safety.score)
    return `The fastest route (${fastest.durationMin} min) also has the top prototype score, so there is no time-versus-safety trade-off here.`;
  const extra = best.durationMin - fastest.durationMin;
  return `${best.label} scores ≈${best.safety.score} versus ${fastest.safety.score == null ? 'no score' : `≈${fastest.safety.score}`} for the fastest route, for ${extra} more minute${extra === 1 ? '' : 's'}. In this prototype the difference comes only from hospital proximity, so treat it as a hint, not a safety guarantee.`;
}

function Coverage({ cov }) {
  if (!cov) return <p className="note">Hospital coverage along this route is unavailable (no hospital data for the area).</p>;
  return (
    <>
      <div className="strip" role="img" aria-label="Hospital coverage along the route from start to end">
        {cov.map((c, i) => <span key={i} style={{ background: COVER_COLORS[c.level] }} title={`Nearest mapped hospital ${c.nearestHospitalKm} km`} />)}
      </div>
      <p className="note small">Start → End. <b style={{ color: COVER_COLORS.near }}>■</b> hospital within 5 km · <b style={{ color: COVER_COLORS.moderate }}>■</b> 5–15 km · <b style={{ color: COVER_COLORS.far }}>■</b> over 15 km (straight-line distance, OpenStreetMap data; may be incomplete).</p>
    </>
  );
}

function Safety({ s }) {
  return (
    <div className="safety">
      <div className="score-row">
        <div className="score" aria-label={s.score == null ? 'No score' : `Score about ${s.score} out of 100`}>{s.score == null ? '—' : `≈${s.score}`}<small>/100</small></div>
        <Badge text={s.status} />
      </div>
      <p className="note small">{s.disclaimer}</p>
      <table>
        <caption className="sr">Safety score factors</caption>
        <thead><tr><th>Factor</th><th>Value</th><th>Weight</th><th>Why / source</th></tr></thead>
        <tbody>
          {s.factors.map((f) => (
            <tr key={f.key}>
              <td>{f.label}</td>
              <td>{f.status === 'scored' ? f.value : <Badge text="DATA UNAVAILABLE" />}</td>
              <td>{f.weight == null ? '—' : `${Math.round(f.weight * 100)}%`}</td>
              <td>{f.reason} <em>({f.source})</em></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function RouteDetails() {
  const { id } = useParams();
  const nav = useNavigate();
  const [r, setR] = useState(null);
  const [err, setErr] = useState('');
  const [sel, setSel] = useState(0);
  const [shareMsg, setShareMsg] = useState('');

  useEffect(() => {
    setR(null); setErr('');
    api(`/routes/${id}`).then(setR).catch((e) => setErr(e.status === 404 ? 'Route not found.' : e.message));
  }, [id]);

  if (err) return <div className="page"><p className="error" role="alert">{err}</p><Link to="/history">Back to history</Link></div>;
  if (!r) return <p className="center" role="status">Loading route…</p>;
  const route = r.routes[sel];
  const toggleSave = async () => { const d = await api(`/routes/${r.id}`, { method: 'PATCH', body: { saved: !r.saved } }); setR({ ...r, saved: d.saved }); };
  const del = async () => { if (confirm('Delete this route from your history?')) { await api(`/routes/${r.id}`, { method: 'DELETE' }); nav('/history'); } };
  const brief = () => `GoSafe trip brief (prototype, not official safety advice)
From: ${r.origin.label}
To: ${r.destination.label}
${route.label}: ${route.durationMin} min, ${route.distanceKm} km
Prototype safety estimate: ${route.safety.score == null ? 'insufficient data' : `about ${route.safety.score}/100`}
Start point: ${osmLink(r.origin.lat, r.origin.lon)}`;
  const fastest = Math.min(...r.routes.map((x) => x.durationMin));

  return (
    <div className="page">
      <h1>{r.origin.label.split(',')[0]} → {r.destination.label.split(',')[0]}</h1>
      <p className="note small">Planned {new Date(r.generatedAt).toLocaleString()}</p>
      <div className="row">
        <button className="secondary" onClick={toggleSave}>{r.saved ? '★ Saved' : '☆ Save route'}</button>
        <button className="secondary" onClick={del}>Delete</button>
        <button className="secondary" onClick={async () => setShareMsg(await shareText('GoSafe trip brief', brief()))}>Share trip brief</button>
        <Link className="btn secondary" to="/plan">New search</Link>
      </div>
      {shareMsg && <p role="status" className="note">{shareMsg}</p>}
      <MapView routes={r.routes} selected={sel} origin={r.origin} destination={r.destination} coverage={route.coverage} />
      <Legend routes />
      <p className="note small">Dots on the selected route show hospital coverage (green / amber / red).</p>
      <aside className="verdict" aria-label="Route comparison summary"><strong>Quick comparison:</strong> {verdict(r.routes)}</aside>
      <h2>Route options</h2>
      <p className="note small">A higher score is not guaranteed safer, and the fastest route is not automatically the safest. Compare the evidence below.</p>
      <div className="grid">
        {r.routes.map((x, i) => (
          <button key={i} className={`card route-card ${i === sel ? 'sel' : ''}`} aria-pressed={i === sel} onClick={() => setSel(i)} style={{ borderColor: ROUTE_COLORS[i % 4] }}>
            <h3>{x.label}</h3>
            <p><strong>{x.durationMin} min</strong> · {x.distanceKm} km{x.durationMin === fastest && ' · fastest'}</p>
            <p>Score: {x.safety.score == null ? 'insufficient data' : `≈${x.safety.score}/100`}</p>
            <Badge text={x.safety.status} /> <Badge text={provBadge(r.provenance.routing)} />
          </button>
        ))}
      </div>
      <h2>Safety evidence for: {route.label}</h2>
      <h3>Hospital coverage along the route</h3>
      <Coverage cov={route.coverage} />
      <Safety s={route.safety} />
      {r.weather && <p className="note">Weather at the start point only ({r.weather.temperature}°C, {r.weather.precipitation} mm precipitation, wind {r.weather.windSpeed} km/h). Weather elsewhere on the route is not known.</p>}
      <h2>Data sources</h2>
      <table>
        <thead><tr><th>Data</th><th>Provider</th><th>Type</th><th>Fetched</th><th>Notes</th></tr></thead>
        <tbody>
          {Object.entries(r.provenance).map(([k, p]) => (
            <tr key={k}><td>{k}</td><td>{p.provider}</td><td><Badge text={provBadge(p)} /></td><td>{new Date(p.fetchedAt).toLocaleTimeString()}</td><td>{p.note || p.coverage || ''} {p.attribution}</td></tr>
          ))}
          <tr><td>accident history, live traffic, road conditions</td><td>—</td><td><Badge text="DATA UNAVAILABLE" /></td><td>—</td><td>No verified dataset connected.</td></tr>
        </tbody>
      </table>
    </div>
  );
}
