import { useState } from 'react';
import LocationPicker from '../components/LocationPicker.jsx';
import FacilitiesPanel from '../components/FacilitiesPanel.jsx';

export default function Facilities() {
  const [loc, setLoc] = useState(null);
  return (
    <div className="page">
      <h1>Nearby Facilities</h1>
      <p>Hospitals, police stations, petrol stations, rest areas and ambulance stations mapped in OpenStreetMap near a location.</p>
      <LocationPicker id="fac-loc" label="Location" value={loc} onPick={setLoc} allowGeo />
      <FacilitiesPanel location={loc} withRouteLinks />
    </div>
  );
}
