import { Link } from 'react-router-dom';
import { useAuth } from '../auth.jsx';
import { Badge } from '../components/Badge.jsx';

const FEATURES = [
  ['Safe Route Finder', 'Compare alternative routes by time, distance and available safety information.', null],
  ['Explainable Safety Score', 'A 0–100 prototype score with every factor, source and gap shown.', 'PROTOTYPE ESTIMATE'],
  ['Risk-Ahead Alerts', 'Weather advisory for the route origin today; accident-prone-area alerts need a verified dataset.', 'UPCOMING'],
  ['Emergency Mode', 'Emergency numbers, trusted contacts and nearby hospitals / police. No automatic calling or SOS.', null],
  ['Emergency & Rest Stops', 'Hospitals, petrol stations and rest areas from OpenStreetMap. Ambulance priority routing is not available.', null],
];

export default function Home() {
  const { user } = useAuth();
  return (
    <div className="page">
      <section className="hero">
        <h1>Not just the fastest way.<br />A smarter, safer way to reach your destination.</h1>
        <p>GoSafe helps you compare routes using travel time and the safety information that is actually available, and tells you honestly what is missing.</p>
        <Link className="btn" to={user ? '/plan' : '/register'}>Plan Safe Route</Link>
        {!user && <Link className="btn secondary" to="/login">Log in</Link>}
      </section>
      <h2>What GoSafe does</h2>
      <div className="grid">
        {FEATURES.map(([t, d, b]) => (
          <article className="card" key={t}><h3>{t}</h3><p>{d}</p>{b && <Badge text={b} />}</article>
        ))}
      </div>
      <p className="note">See <Link to="/about">How it works</Link> for exactly which parts are real data, estimates or planned.</p>
    </div>
  );
}
