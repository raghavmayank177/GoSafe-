import { useState } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth.jsx';

function AuthForm({ mode }) {
  const { user, login, register } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const [f, setF] = useState({ name: '', email: '', password: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const isReg = mode === 'register';
  if (user) return <Navigate to="/dashboard" replace />;

  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  async function submit(e) {
    e.preventDefault();
    setErr('');
    if (isReg && !f.name.trim()) return setErr('Please enter your name.');
    if (!/^\S+@\S+\.\S+$/.test(f.email)) return setErr('Please enter a valid email address.');
    if (isReg && f.password.length < 8) return setErr('Password must be at least 8 characters.');
    setBusy(true);
    try {
      if (isReg) await register(f.name, f.email, f.password); else await login(f.email, f.password);
      nav(loc.state?.from || '/dashboard', { replace: true });
    } catch (e2) {
      setErr(e2.details?.[0]?.message || e2.message);
    } finally { setBusy(false); }
  }
  return (
    <div className="page narrow">
      <h1>{isReg ? 'Create your GoSafe account' : 'Log in to GoSafe'}</h1>
      <form onSubmit={submit} noValidate>
        {isReg && <><label htmlFor="name">Name</label><input id="name" autoComplete="name" value={f.name} onChange={set('name')} /></>}
        <label htmlFor="email">Email</label>
        <input id="email" type="email" autoComplete="email" value={f.email} onChange={set('email')} />
        <label htmlFor="password">Password {isReg && <small>(min 8 characters)</small>}</label>
        <input id="password" type="password" autoComplete={isReg ? 'new-password' : 'current-password'} value={f.password} onChange={set('password')} />
        {err && <p className="error" role="alert">{err}</p>}
        <button type="submit" disabled={busy}>{busy ? 'Please wait…' : isReg ? 'Register' : 'Log in'}</button>
      </form>
      <p>{isReg ? <>Already registered? <Link to="/login">Log in</Link></> : <>New here? <Link to="/register">Create an account</Link></>}</p>
      <p className="note small">Your password is hashed (bcrypt) on the server. It is never stored in plain text.</p>
    </div>
  );
}
export const Login = () => <AuthForm mode="login" />;
export const Register = () => <AuthForm mode="register" />;
