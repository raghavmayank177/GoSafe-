import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Layout from './components/Layout.jsx';
import { useAuth } from './auth.jsx';
import Home from './pages/Home.jsx';
import { Login, Register } from './pages/AuthPages.jsx';
import Dashboard from './pages/Dashboard.jsx';
import PlanRoute from './pages/PlanRoute.jsx';
import RouteDetails from './pages/RouteDetails.jsx';
import History from './pages/History.jsx';
import Emergency from './pages/Emergency.jsx';
import Facilities from './pages/Facilities.jsx';
import Profile from './pages/Profile.jsx';
import Status from './pages/Status.jsx';
import { About, Upcoming, NotFound } from './pages/Static.jsx';

function Protected({ children }) {
  const { user, loading } = useAuth();
  const loc = useLocation();
  if (loading) return <p className="center" role="status">Loading…</p>;
  if (!user) return <Navigate to="/login" replace state={{ from: loc.pathname + loc.search }} />;
  return children;
}

export default function App() {
  const p = (el) => <Protected>{el}</Protected>;
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="login" element={<Login />} />
        <Route path="register" element={<Register />} />
        <Route path="about" element={<About />} />
        <Route path="upcoming" element={<Upcoming />} />
        <Route path="dashboard" element={p(<Dashboard />)} />
        <Route path="plan" element={p(<PlanRoute />)} />
        <Route path="routes/:id" element={p(<RouteDetails />)} />
        <Route path="history" element={p(<History />)} />
        <Route path="emergency" element={p(<Emergency />)} />
        <Route path="facilities" element={p(<Facilities />)} />
        <Route path="status" element={p(<Status />)} />
        <Route path="profile" element={p(<Profile />)} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
