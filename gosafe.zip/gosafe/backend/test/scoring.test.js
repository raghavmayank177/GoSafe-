import test from 'node:test';
import assert from 'node:assert/strict';
process.env.JWT_SECRET ||= 'x'.repeat(40);
const { computeSafetyScore, emergencyAccessValue, weatherValue } = await import('../src/scoring.js');

const NOW = Date.parse('2026-10-16T12:00:00Z');
const route = [[77.0, 28.0], [77.05, 28.05], [77.1, 28.1]]; // [lon,lat]
const nearHospital = [{ lat: 28.05, lon: 77.05 }];
const farHospital = [{ lat: 10, lon: 70 }];
const calmWeather = { time: '2026-10-16T11:30', precipitation: 0, windSpeed: 5, weatherCode: 1 };

test('hospital near route scores high, far hospital scores low', () => {
  assert.ok(emergencyAccessValue(route, nearHospital) > 90);
  assert.equal(emergencyAccessValue(route, farHospital), 0);
});

test('no hospital data => null (not zero)', () => {
  assert.equal(emergencyAccessValue(route, []), null);
  assert.equal(emergencyAccessValue(route, null), null);
});

test('missing hospital data => INSUFFICIENT DATA and no score', () => {
  const r = computeSafetyScore({ emergencyAccess: null, weather: calmWeather }, NOW);
  assert.equal(r.status, 'INSUFFICIENT DATA');
  assert.equal(r.score, null);
});

test('missing weather => still scored from emergency access, weather listed as not scored', () => {
  const r = computeSafetyScore({ emergencyAccess: 100, weather: null }, NOW);
  assert.equal(r.status, 'PROTOTYPE ESTIMATE');
  assert.equal(r.score, 100);
  assert.equal(r.factors.find((f) => f.key === 'weather').status, 'not_scored');
});

test('stale weather is not scored', () => {
  const stale = { ...calmWeather, time: '2026-10-16T05:00' };
  assert.equal(weatherValue(stale, NOW).value, null);
});

test('heavy rain lowers score; unverified factors never scored', () => {
  const stormy = { time: '2026-10-16T11:50', precipitation: 4, windSpeed: 50, weatherCode: 95 };
  const calm = computeSafetyScore({ emergencyAccess: 100, weather: calmWeather }, NOW);
  const bad = computeSafetyScore({ emergencyAccess: 100, weather: stormy }, NOW);
  assert.ok(bad.score < calm.score);
  for (const k of ['accidentHistory', 'traffic', 'roadCondition']) {
    assert.equal(bad.factors.find((f) => f.key === k).status, 'not_scored');
  }
});

test('score is rounded to nearest 5 (no false precision)', () => {
  const r = computeSafetyScore({ emergencyAccess: 63, weather: calmWeather }, NOW);
  assert.equal(r.score % 5, 0);
});

test('coverage profile labels near/far and returns null without data', async () => {
  const { coverageProfile } = await import('../src/scoring.js');
  assert.equal(coverageProfile(route, []), null);
  const hospitalsEverywhere = route.map(([lon, lat]) => ({ lat, lon }));
  assert.ok(coverageProfile(route, hospitalsEverywhere).every((p) => p.level === 'near'));
  assert.ok(coverageProfile(route, nearHospital).some((p) => p.level === 'moderate'));
  assert.ok(coverageProfile(route, farHospital).every((p) => p.level === 'far'));
});
