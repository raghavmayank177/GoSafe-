// Integration tests using an in-memory SQLite DB and fake providers (no network).
// Requires `npm install` first (better-sqlite3, express, ...).
import test from 'node:test';
import assert from 'node:assert/strict';
process.env.JWT_SECRET = 'test-secret-'.padEnd(40, 'x');
process.env.FRONTEND_ORIGIN = 'http://localhost:5173';
const { openDb } = await import('../src/db.js');
const { createApp } = await import('../src/app.js');
const { ProviderError } = await import('../src/errors.js');
const providers = await import('../src/providers.js');

const route = { distanceKm: 10, durationMin: 15, coordinates: [[77, 28], [77.05, 28.05], [77.1, 28.1]] };
const okDeps = {
  ...providers,
  geocode: async () => ({ results: [], provenance: {} }),
  getRoutes: async () => ({ routes: [route, { ...route, durationMin: 20 }], provenance: { provider: 'fake', kind: 'estimated', status: 'ok' } }),
  getWeather: async () => ({ weather: { time: new Date().toISOString().slice(0, 16), precipitation: 0, windSpeed: 5, weatherCode: 1 }, provenance: { provider: 'fake', kind: 'forecast', status: 'ok' } }),
  getHospitalsInBox: async () => [{ lat: 28.05, lon: 77.05 }],
};

async function start(deps = okDeps) {
  const server = createApp(openDb(':memory:'), deps).listen(0);
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, path, body, cookie) => {
    const res = await fetch(base + path, {
      method,
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'gosafe', ...(cookie ? { Cookie: cookie } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    return { res, json: await res.json().catch(() => ({})) };
  };
  const register = async (email) => {
    const { res } = await call('POST', '/api/auth/register', { name: 'T', email, password: 'password123' });
    return res.headers.get('set-cookie').split(';')[0];
  };
  return { server, call, register };
}
const place = (l) => ({ label: l, lat: 28, lon: 77 });
const plan = { origin: place('A'), destination: { label: 'B', lat: 28.1, lon: 77.1 } };

test('register hashes password, login works, wrong password rejected, /me needs cookie', async () => {
  const { server, call } = await start();
  await call('POST', '/api/auth/register', { name: 'A', email: 'a@x.com', password: 'password123' });
  assert.equal((await call('POST', '/api/auth/login', { email: 'a@x.com', password: 'nope' })).res.status, 401);
  assert.equal((await call('POST', '/api/auth/login', { email: 'a@x.com', password: 'password123' })).res.status, 200);
  assert.equal((await call('GET', '/api/auth/me')).res.status, 401);
  server.close();
});

test('malformed input => 400; missing CSRF header => 403', async () => {
  const { server, call } = await start();
  assert.equal((await call('POST', '/api/auth/register', { email: 'bad', password: '1' })).res.status, 400);
  const res = await fetch(`http://127.0.0.1:${server.address().port}/api/auth/logout`, { method: 'POST' });
  assert.equal(res.status, 403);
  server.close();
});

test('route planning saves history; missing weather still works with provenance', async () => {
  const { server, call, register } = await start({ ...okDeps, getWeather: async () => { throw new ProviderError('Open-Meteo', 'timed out'); } });
  const c = await register('w@x.com');
  const { res, json } = await call('POST', '/api/routes/plan', plan, c);
  assert.equal(res.status, 201);
  assert.equal(json.provenance.weather.status, 'unavailable');
  assert.equal(json.routes[0].safety.factors.find((f) => f.key === 'weather').status, 'not_scored');
  assert.equal((await call('GET', '/api/routes', null, c)).json.routes.length, 1);
  server.close();
});

test('routing provider failure => 502, app keeps running', async () => {
  const { server, call, register } = await start({ ...okDeps, getRoutes: async () => { throw new ProviderError('OSRM', 'timed out'); } });
  const c = await register('f@x.com');
  assert.equal((await call('POST', '/api/routes/plan', plan, c)).res.status, 502);
  assert.equal((await call('GET', '/api/health')).res.status, 200);
  server.close();
});

test('users cannot read or delete each other\'s routes', async () => {
  const { server, call, register } = await start();
  const a = await register('a1@x.com');
  const b = await register('b1@x.com');
  const { json } = await call('POST', '/api/routes/plan', plan, a);
  assert.equal((await call('GET', `/api/routes/${json.id}`, null, b)).res.status, 404);
  assert.equal((await call('DELETE', `/api/routes/${json.id}`, null, b)).res.status, 404);
  assert.equal((await call('GET', `/api/routes/${json.id}`, null, a)).res.status, 200);
  server.close();
});

test('provenance is stored and returned for each data source', async () => {
  const { server, call, register } = await start();
  const c = await register('p@x.com');
  const { json } = await call('POST', '/api/routes/plan', plan, c);
  const saved = (await call('GET', `/api/routes/${json.id}`, null, c)).json;
  for (const k of ['routing', 'weather', 'facilities']) assert.ok(saved.provenance[k].provider);
  server.close();
});
