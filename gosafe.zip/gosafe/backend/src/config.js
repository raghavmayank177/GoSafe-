import 'dotenv/config';

const env = process.env;
const jwtSecret = env.JWT_SECRET || '';
if (jwtSecret.length < 32) {
  throw new Error(
    'JWT_SECRET is missing or shorter than 32 characters. Copy .env.example to .env and set it ' +
      '(see README for the command that generates one).'
  );
}

export const config = {
  port: Number(env.PORT || 4000),
  production: env.NODE_ENV === 'production',
  frontendOrigin: env.FRONTEND_ORIGIN || 'http://localhost:5173',
  jwtSecret,
  dbPath: env.DATABASE_PATH || './data/gosafe.db',
  osrmUrl: env.OSRM_BASE_URL || 'https://router.project-osrm.org',
  nominatimUrl: env.NOMINATIM_BASE_URL || 'https://nominatim.openstreetmap.org',
  overpassUrl: env.OVERPASS_URL || 'https://overpass-api.de/api/interpreter',
  openMeteoUrl: env.OPEN_METEO_URL || 'https://api.open-meteo.com',
  userAgent: env.PROVIDER_USER_AGENT || 'GoSafe-student-project (set PROVIDER_USER_AGENT)',
  timeoutMs: Number(env.PROVIDER_TIMEOUT_MS || 9000),
};
