import { config } from './config.js';
import { ProviderError } from './errors.js';

const cache = new Map();
function cached(key, ttlMs, producer) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return Promise.resolve(hit.value);
  return producer().then((value) => {
    cache.set(key, { at: Date.now(), value });
    if (cache.size > 300) cache.delete(cache.keys().next().value);
    return value;
  });
}

async function fetchJson(provider, url, init = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), config.timeoutMs);
  try {
    const res = await fetch(url, {
      ...init,
      signal: ctrl.signal,
      headers: { 'User-Agent': config.userAgent, Accept: 'application/json', ...(init.headers || {}) },
    });
    if (!res.ok) throw new ProviderError(provider, `${provider} responded with HTTP ${res.status}`);
    return await res.json();
  } catch (e) {
    if (e instanceof ProviderError) throw e;
    if (e.name === 'AbortError') throw new ProviderError(provider, `${provider} timed out`);
    throw new ProviderError(provider, `${provider} unreachable`);
  } finally {
    clearTimeout(timer);
  }
}

export const provenance = (provider, o) => ({
  provider,
  fetchedAt: new Date().toISOString(),
  ...o,
});

export async function geocode(q) {
  const data = await cached(`geo:${q.toLowerCase()}`, 3600_000, () =>
    fetchJson('Nominatim', `${config.nominatimUrl}/search?format=jsonv2&limit=5&q=${encodeURIComponent(q)}`)
  );
  return {
    results: data.map((d) => ({ label: d.display_name, lat: Number(d.lat), lon: Number(d.lon) })),
    provenance: provenance('Nominatim (OpenStreetMap)', {
      kind: 'observed',
      status: 'ok',
      attribution: '© OpenStreetMap contributors (ODbL)',
    }),
  };
}

export async function getRoutes(o, d) {
  const url =
    `${config.osrmUrl}/route/v1/driving/${o.lon},${o.lat};${d.lon},${d.lat}` +
    `?alternatives=true&overview=full&geometries=geojson&steps=false`;
  const data = await fetchJson('OSRM', url);
  if (data.code !== 'Ok' || !data.routes?.length) {
    throw new ProviderError('OSRM', `No drivable route found (${data.code || 'unknown'})`);
  }
  return {
    routes: data.routes.map((r) => ({
      distanceKm: r.distance / 1000,
      durationMin: r.duration / 60,
      coordinates: r.geometry.coordinates,
    })),
    provenance: provenance('OSRM public demo server (OpenStreetMap data)', {
      kind: 'estimated',
      status: 'ok',
      note: 'Road geometry and free-flow time estimate. No live traffic. Demo server is not for production.',
      attribution: '© OpenStreetMap contributors (ODbL)',
    }),
  };
}

export async function getWeather(lat, lon) {
  const url =
    `${config.openMeteoUrl}/v1/forecast?latitude=${lat}&longitude=${lon}` +
    `&current=temperature_2m,precipitation,weather_code,wind_speed_10m&timezone=GMT`;
  const data = await cached(`wx:${lat.toFixed(2)},${lon.toFixed(2)}`, 600_000, () => fetchJson('Open-Meteo', url));
  const c = data.current;
  if (!c) throw new ProviderError('Open-Meteo', 'Open-Meteo returned no current conditions');
  return {
    weather: {
      time: c.time,
      temperature: c.temperature_2m,
      precipitation: c.precipitation,
      windSpeed: c.wind_speed_10m,
      weatherCode: c.weather_code,
    },
    provenance: provenance('Open-Meteo', {
      kind: 'forecast',
      status: 'ok',
      coverage: `Single point (${lat.toFixed(2)}, ${lon.toFixed(2)}) at the route origin, not the whole route`,
      attribution: 'Weather data by Open-Meteo.com (CC BY 4.0)',
    }),
  };
}

const CATEGORY_QUERIES = {
  hospital: '["amenity"="hospital"]',
  police: '["amenity"="police"]',
  fuel: '["amenity"="fuel"]',
  rest_area: '["highway"="rest_area"]',
  ambulance_station: '["emergency"="ambulance_station"]',
};

async function overpass(body) {
  const data = await fetchJson('Overpass', config.overpassUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `data=${encodeURIComponent(body)}`,
  });
  return (data.elements || [])
    .map((e) => ({
      id: `${e.type}/${e.id}`,
      lat: e.lat ?? e.center?.lat,
      lon: e.lon ?? e.center?.lon,
      name: e.tags?.name || null,
      tags: e.tags || {},
    }))
    .filter((e) => Number.isFinite(e.lat) && Number.isFinite(e.lon));
}

const categoryOf = (t) =>
  t.amenity === 'hospital' ? 'hospital'
  : t.amenity === 'police' ? 'police'
  : t.amenity === 'fuel' ? 'fuel'
  : t.highway === 'rest_area' ? 'rest_area'
  : t.emergency === 'ambulance_station' ? 'ambulance_station'
  : 'other';

export async function getFacilities(lat, lon, radiusM = 8000) {
  const r = Math.min(Math.max(radiusM, 1000), 25000);
  const parts = Object.values(CATEGORY_QUERIES).map((q) => `nwr${q}(around:${r},${lat},${lon});`).join('');
  const body = `[out:json][timeout:15];(${parts});out center tags 120;`;
  const items = await cached(`fac:${lat.toFixed(3)},${lon.toFixed(3)},${r}`, 600_000, () => overpass(body));
  return {
    facilities: items.map((i) => ({ ...i, category: categoryOf(i.tags), tags: undefined })),
    provenance: provenance('OpenStreetMap via Overpass API', {
      kind: 'observed',
      status: 'ok',
      note: 'Community-mapped data; may be incomplete or outdated. Phone numbers/hours are not verified here.',
      attribution: '© OpenStreetMap contributors (ODbL)',
    }),
  };
}

export async function getHospitalsInBox(coordsList) {
  const lats = coordsList.map((c) => c[1]);
  const lons = coordsList.map((c) => c[0]);
  const pad = 0.1;
  const s = Math.min(...lats) - pad, n = Math.max(...lats) + pad;
  const w = Math.min(...lons) - pad, e = Math.max(...lons) + pad;
  if (n - s > 3 || e - w > 3) throw new ProviderError('Overpass', 'Route area too large for hospital lookup');
  const body = `[out:json][timeout:15];nwr["amenity"="hospital"](${s},${w},${n},${e});out center tags 300;`;
  return cached(`hbox:${s.toFixed(2)},${w.toFixed(2)},${n.toFixed(2)},${e.toFixed(2)}`, 600_000, () => overpass(body));
}

export async function checkProviders() {
  const timed = async (name, fn) => {
    const t0 = Date.now();
    try { await fn(); return { name, ok: true, ms: Date.now() - t0 }; }
    catch (e) { return { name, ok: false, ms: Date.now() - t0, error: e.message }; }
  };
  return Promise.all([
    timed('Routing (OSRM)', () => fetchJson('OSRM', `${config.osrmUrl}/route/v1/driving/77.209,28.6139;77.2273,28.6129?overview=false`)),
    timed('Place search (Nominatim)', () => fetchJson('Nominatim', `${config.nominatimUrl}/search?format=jsonv2&limit=1&q=Delhi`)),
    timed('Weather (Open-Meteo)', () => fetchJson('Open-Meteo', `${config.openMeteoUrl}/v1/forecast?latitude=28.61&longitude=77.21&current=temperature_2m`)),
    timed('Facilities (Overpass)', () => overpass('[out:json][timeout:10];node["amenity"="hospital"](28.6,77.2,28.62,77.22);out 1;')),
  ]);
}

export const unavailable = (provider, reason) =>
  provenance(provider, { kind: 'unavailable', status: 'unavailable', note: reason });
