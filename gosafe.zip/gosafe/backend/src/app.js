import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { config } from './config.js';
import { HttpError, ProviderError } from './errors.js';
import * as providers from './providers.js';
import { computeSafetyScore, emergencyAccessValue, coverageProfile } from './scoring.js';

const COOKIE = 'gosafe_token';
const TOKEN_HOURS = 12;

const place = z.object({
  label: z.string().trim().min(1).max(300),
  lat: z.number().min(-90).max(90),
  lon: z.number().min(-180).max(180),
});
const registerSchema = z.object({
  name: z.string().trim().min(1).max(80),
  email: z.string().trim().toLowerCase().email().max(200),
  password: z.string().min(8, 'Password must be at least 8 characters').max(128),
});
const loginSchema = z.object({ email: z.string().trim().toLowerCase().email(), password: z.string().min(1).max(128) });
const planSchema = z.object({ origin: place, destination: place });
const contactSchema = z.object({
  name: z.string().trim().min(1).max(80),
  phone: z.string().trim().regex(/^\+?[0-9 ()-]{3,20}$/, 'Enter a valid phone number'),
});

// Express 4 does not forward rejected promises from async handlers to the error middleware.
const wrap = (fn) => (req, res, next) => {
  try {
    const r = fn(req, res, next);
    if (r && typeof r.catch === 'function') r.catch(next);
  } catch (e) {
    next(e);
  }
};

export function createApp(db, deps = providers) {
  const app = express();
  for (const m of ['get', 'post', 'patch', 'delete']) {
    const orig = app[m].bind(app);
    app[m] = (path, ...handlers) => (handlers.length ? orig(path, ...handlers.map((h) => (h.length >= 4 ? h : wrap(h)))) : orig(path));
  }
  app.disable('x-powered-by');
  app.use(helmet());
  app.use(cors({ origin: config.frontendOrigin, credentials: true }));
  app.use(express.json({ limit: '100kb' }));
  app.use(cookieParser());

  // CSRF defence for cookie auth: SameSite=Lax cookie + CORS allow-list + a custom header that
  // browsers will not send cross-site without a CORS preflight (which we only allow for our origin).
  app.use((req, res, next) => {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
    if (req.get('x-requested-with') !== 'gosafe') return next(new HttpError(403, 'Missing CSRF header', 'csrf'));
    next();
  });

  const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });
  const providerLimiter = rateLimit({ windowMs: 60 * 1000, limit: 60, standardHeaders: true, legacyHeaders: false });

  const setCookie = (res, user) => {
    const token = jwt.sign({ sub: user.id }, config.jwtSecret, { expiresIn: `${TOKEN_HOURS}h` });
    res.cookie(COOKIE, token, {
      httpOnly: true, sameSite: 'lax', secure: config.production, maxAge: TOKEN_HOURS * 3600_000, path: '/',
    });
  };
  const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, createdAt: u.created_at });

  const requireAuth = (req, _res, next) => {
    try {
      const payload = jwt.verify(req.cookies[COOKIE] || '', config.jwtSecret);
      const user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.sub);
      if (!user) throw new Error('no user');
      req.user = user;
      next();
    } catch {
      next(new HttpError(401, 'Please log in', 'unauthenticated'));
    }
  };

  app.get('/api/health', (_req, res) => res.json({ ok: true }));

  // ---- auth
  app.post('/api/auth/register', authLimiter, (req, res) => {
    const { name, email, password } = registerSchema.parse(req.body);
    if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) throw new HttpError(409, 'Email already registered', 'email_taken');
    const hash = bcrypt.hashSync(password, 12);
    const info = db.prepare('INSERT INTO users (email, name, password_hash) VALUES (?, ?, ?)').run(email, name, hash);
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
    setCookie(res, user);
    res.status(201).json({ user: publicUser(user) });
  });

  app.post('/api/auth/login', authLimiter, (req, res) => {
    const { email, password } = loginSchema.parse(req.body);
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    const ok = user && bcrypt.compareSync(password, user.password_hash);
    if (!ok) throw new HttpError(401, 'Invalid email or password', 'bad_credentials');
    setCookie(res, user);
    res.json({ user: publicUser(user) });
  });

  app.post('/api/auth/logout', (_req, res) => {
    res.clearCookie(COOKIE, { path: '/' });
    res.json({ ok: true });
  });

  app.get('/api/auth/me', requireAuth, (req, res) => res.json({ user: publicUser(req.user) }));

  app.patch('/api/profile', requireAuth, (req, res) => {
    const { name } = z.object({ name: z.string().trim().min(1).max(80) }).parse(req.body);
    db.prepare('UPDATE users SET name = ? WHERE id = ?').run(name, req.user.id);
    res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)) });
  });

  // ---- providers (auth-protected so the public demo servers are not open to anyone)
  app.get('/api/geocode', requireAuth, providerLimiter, async (req, res) => {
    const { q } = z.object({ q: z.string().trim().min(2).max(200) }).parse(req.query);
    res.json(await deps.geocode(q));
  });

  app.get('/api/facilities', requireAuth, providerLimiter, async (req, res) => {
    const q = z.object({
      lat: z.coerce.number().min(-90).max(90),
      lon: z.coerce.number().min(-180).max(180),
      radius: z.coerce.number().min(1000).max(25000).default(8000),
    }).parse(req.query);
    res.json(await deps.getFacilities(q.lat, q.lon, q.radius));
  });

  // Pre-demo health check of every external provider (never required for the app to run).
  app.get('/api/status', requireAuth, rateLimit({ windowMs: 60_000, limit: 6 }), async (_req, res) => {
    res.json({ checkedAt: new Date().toISOString(), providers: await deps.checkProviders() });
  });

  // ---- route planning
  const label = (i) => (i === 0 ? 'Recommended by routing engine (fastest)' : `Alternative ${i}`);

  app.post('/api/routes/plan', requireAuth, providerLimiter, async (req, res) => {
    const { origin, destination } = planSchema.parse(req.body);
    const routing = await deps.getRoutes(origin, destination); // failure => 502 below

    const allCoords = routing.routes.flatMap((r) => r.coordinates);
    const [wx, hosp] = await Promise.allSettled([
      deps.getWeather(origin.lat, origin.lon),
      deps.getHospitalsInBox(allCoords),
    ]);
    const weather = wx.status === 'fulfilled' ? wx.value.weather : null;
    const weatherProv = wx.status === 'fulfilled'
      ? wx.value.provenance
      : providers.unavailable('Open-Meteo', wx.reason?.message || 'unavailable');
    const hospitals = hosp.status === 'fulfilled' ? hosp.value : null;
    const facilityProv = hosp.status === 'fulfilled'
      ? providers.provenance('OpenStreetMap via Overpass API', {
          kind: 'observed', status: hospitals.length ? 'ok' : 'empty',
          note: `${hospitals.length} hospitals mapped in the route area (community-mapped; may be incomplete).`,
          attribution: '© OpenStreetMap contributors (ODbL)',
        })
      : providers.unavailable('Overpass', hosp.reason?.message || 'unavailable');

    const routes = routing.routes.map((r, i) => ({
      index: i,
      label: label(i),
      distanceKm: Math.round(r.distanceKm * 10) / 10,
      durationMin: Math.round(r.durationMin),
      coordinates: r.coordinates,
      coverage: hospitals ? coverageProfile(r.coordinates, hospitals) : null,
      safety: computeSafetyScore({
        emergencyAccess: hospitals ? emergencyAccessValue(r.coordinates, hospitals) : null,
        weather,
      }),
    }));

    const result = {
      origin, destination, routes, weather,
      provenance: { routing: routing.provenance, weather: weatherProv, facilities: facilityProv },
      generatedAt: new Date().toISOString(),
    };
    const info = db.prepare(
      `INSERT INTO routes (user_id, origin_label, origin_lat, origin_lon, dest_label, dest_lat, dest_lon, result_json)
       VALUES (?,?,?,?,?,?,?,?)`
    ).run(req.user.id, origin.label, origin.lat, origin.lon, destination.label, destination.lat, destination.lon, JSON.stringify(result));
    res.status(201).json({ id: Number(info.lastInsertRowid), saved: false, ...result });
  });

  const summary = (r) => ({
    id: r.id, origin: r.origin_label, destination: r.dest_label, saved: !!r.saved, createdAt: r.created_at,
  });
  const ownedRoute = (req) => {
    const id = z.coerce.number().int().positive().parse(req.params.id);
    const row = db.prepare('SELECT * FROM routes WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!row) throw new HttpError(404, 'Route not found', 'not_found'); // 404 also hides other users' ids
    return row;
  };

  app.get('/api/routes', requireAuth, (req, res) => {
    const savedOnly = req.query.saved === '1';
    const rows = db.prepare(
      `SELECT * FROM routes WHERE user_id = ? ${savedOnly ? 'AND saved = 1' : ''} ORDER BY created_at DESC, id DESC LIMIT 50`
    ).all(req.user.id);
    res.json({ routes: rows.map(summary) });
  });
  app.get('/api/routes/:id', requireAuth, (req, res) => {
    const row = ownedRoute(req);
    res.json({ id: row.id, saved: !!row.saved, createdAt: row.created_at, ...JSON.parse(row.result_json) });
  });
  app.patch('/api/routes/:id', requireAuth, (req, res) => {
    const row = ownedRoute(req);
    const { saved } = z.object({ saved: z.boolean() }).parse(req.body);
    db.prepare('UPDATE routes SET saved = ? WHERE id = ?').run(saved ? 1 : 0, row.id);
    res.json({ id: row.id, saved });
  });
  app.delete('/api/routes/:id', requireAuth, (req, res) => {
    const row = ownedRoute(req);
    db.prepare('DELETE FROM routes WHERE id = ?').run(row.id);
    res.json({ ok: true });
  });

  // ---- trusted contacts
  app.get('/api/contacts', requireAuth, (req, res) => {
    res.json({ contacts: db.prepare('SELECT id, name, phone FROM contacts WHERE user_id = ? ORDER BY id').all(req.user.id) });
  });
  app.post('/api/contacts', requireAuth, (req, res) => {
    const c = contactSchema.parse(req.body);
    const n = db.prepare('SELECT COUNT(*) AS n FROM contacts WHERE user_id = ?').get(req.user.id).n;
    if (n >= 5) throw new HttpError(400, 'Maximum 5 trusted contacts', 'limit');
    const info = db.prepare('INSERT INTO contacts (user_id, name, phone) VALUES (?,?,?)').run(req.user.id, c.name, c.phone);
    res.status(201).json({ contact: { id: Number(info.lastInsertRowid), ...c } });
  });
  app.delete('/api/contacts/:id', requireAuth, (req, res) => {
    const id = z.coerce.number().int().positive().parse(req.params.id);
    const info = db.prepare('DELETE FROM contacts WHERE id = ? AND user_id = ?').run(id, req.user.id);
    if (!info.changes) throw new HttpError(404, 'Contact not found', 'not_found');
    res.json({ ok: true });
  });

  app.use('/api', (_req, _res, next) => next(new HttpError(404, 'Unknown API endpoint', 'not_found')));

  // Express 4 does not catch async rejections; wrap via this central handler + patch below.
  // eslint-disable-next-line no-unused-vars
  app.use((err, _req, res, _next) => {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: 'Invalid input', code: 'validation', details: err.issues.map((i) => ({ path: i.path.join('.'), message: i.message })) });
    }
    if (err instanceof HttpError) return res.status(err.status).json({ error: err.message, code: err.code });
    if (err instanceof ProviderError) {
      return res.status(502).json({ error: `${err.provider} is unavailable right now. Please try again.`, code: 'provider_unavailable' });
    }
    if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: 'Malformed JSON', code: 'bad_json' });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong', code: 'internal' });
  });
  return app;
}
