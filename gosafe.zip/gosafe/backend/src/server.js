import { config } from './config.js';
import { openDb } from './db.js';
import { createApp } from './app.js';

const db = openDb(config.dbPath);
const app = createApp(db);
app.listen(config.port, () => {
  console.log(`GoSafe API listening on http://localhost:${config.port}`);
  console.log(`Allowing browser origin: ${config.frontendOrigin}`);
});
