// GoSafe PROTOTYPE safety score. Pure functions, no I/O, fully unit-tested.
// NOT validated road-safety science. Weights and thresholds are prototype assumptions.
//
// Direction: higher = safer (0-100).
// Scored factors (only when their input data exists and is fresh):
//   emergencyAccess (weight 0.6): how close sampled route points are to OSM-mapped hospitals.
//   weather         (weight 0.4): forecast at the ORIGIN POINT only; identical for all routes.
// Missing-data rule: weights are renormalised over available factors. If emergencyAccess
// (the only route-differentiating factor) is unavailable the result is INSUFFICIENT DATA.
// Never scored (no verified dataset connected): accident history, traffic, road condition.

export const WEIGHTS = { emergencyAccess: 0.6, weather: 0.4 };
export const NEAR_KM = 5; // full marks within this distance of a hospital
export const FAR_KM = 30; // zero marks at/after this distance
export const WEATHER_MAX_AGE_MS = 3 * 60 * 60 * 1000;

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

export function haversineKm(a, b) {
  const R = 6371;
  const rad = (d) => (d * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat);
  const dLon = rad(b.lon - a.lon);
  const s =
    Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

// coords: GeoJSON [[lon,lat],...]
export function sampleRoute(coords, n = 12) {
  if (!coords?.length) return [];
  if (coords.length <= n) return coords.map(([lon, lat]) => ({ lat, lon }));
  const out = [];
  for (let i = 0; i < n; i++) {
    const [lon, lat] = coords[Math.round((i * (coords.length - 1)) / (n - 1))];
    out.push({ lat, lon });
  }
  return out;
}

export function emergencyAccessValue(coords, hospitals) {
  if (!Array.isArray(hospitals) || hospitals.length === 0) return null; // empty != "none exist"
  const pts = sampleRoute(coords);
  if (!pts.length) return null;
  const per = pts.map((p) => {
    const d = Math.min(...hospitals.map((h) => haversineKm(p, h)));
    return clamp(100 * (1 - (d - NEAR_KM) / (FAR_KM - NEAR_KM)), 0, 100);
  });
  return per.reduce((a, b) => a + b, 0) / per.length;
}

export function weatherValue(weather, now = Date.now()) {
  if (!weather) return { value: null, reason: 'Weather data unavailable.' };
  const t = Date.parse(weather.time?.endsWith('Z') ? weather.time : `${weather.time}Z`);
  if (!Number.isFinite(t)) return { value: null, reason: 'Weather timestamp invalid; not scored.' };
  if (now - t > WEATHER_MAX_AGE_MS) return { value: null, reason: 'Weather data is stale (>3h); not scored.' };
  let v = 100;
  v -= clamp((weather.precipitation ?? 0) * 20, 0, 50);
  v -= clamp(((weather.windSpeed ?? 0) - 20) * 2, 0, 30);
  if ((weather.weatherCode ?? 0) >= 95) v -= 30; // thunderstorm codes
  return { value: clamp(v, 0, 100), reason: 'Current conditions at the origin point only (same for every route).' };
}

// Per-sample hospital proximity along a route (for the coverage strip). Same thresholds as the score.
export function coverageProfile(coords, hospitals, n = 16) {
  if (!Array.isArray(hospitals) || hospitals.length === 0) return null;
  return sampleRoute(coords, n).map((p) => {
    const d = Math.min(...hospitals.map((h) => haversineKm(p, h)));
    return { lat: p.lat, lon: p.lon, nearestHospitalKm: Math.round(d * 10) / 10, level: d <= NEAR_KM ? 'near' : d <= 15 ? 'moderate' : 'far' };
  });
}

const UNSCORED = [
  ['accidentHistory', 'Verified accident history'],
  ['traffic', 'Live traffic'],
  ['roadCondition', 'Road condition / closures'],
];

export function computeSafetyScore({ emergencyAccess, weather }, now = Date.now()) {
  const w = weatherValue(weather, now);
  const factors = [
    {
      key: 'emergencyAccess',
      label: 'Emergency-service access (hospitals near route)',
      weight: WEIGHTS.emergencyAccess,
      value: emergencyAccess == null ? null : Math.round(emergencyAccess),
      source: 'OpenStreetMap via Overpass (community-mapped)',
      reason:
        emergencyAccess == null
          ? 'No hospital data available for this area; not scored.'
          : `Share of sampled route points near a mapped hospital (full marks within ${NEAR_KM} km, zero beyond ${FAR_KM} km).`,
    },
    {
      key: 'weather',
      label: 'Weather',
      weight: WEIGHTS.weather,
      value: w.value == null ? null : Math.round(w.value),
      source: 'Open-Meteo (forecast model)',
      reason: w.reason,
    },
  ].map((f) => ({ ...f, status: f.value == null ? 'not_scored' : 'scored' }));

  const notScored = UNSCORED.map(([key, label]) => ({
    key,
    label,
    weight: null,
    value: null,
    status: 'not_scored',
    source: 'none',
    reason: 'No verified dataset is connected in this prototype.',
  }));

  const scored = factors.filter((f) => f.status === 'scored');
  const disclaimer =
    'Prototype estimate built from limited data and assumed weights. It is not a validated road-safety assessment.';

  if (!factors[0].value && factors[0].value !== 0) {
    return { score: null, status: 'INSUFFICIENT DATA', factors: [...factors, ...notScored], disclaimer };
  }
  const totalW = scored.reduce((s, f) => s + f.weight, 0);
  const raw = scored.reduce((s, f) => s + f.value * f.weight, 0) / totalW;
  return {
    score: clamp(Math.round(raw / 5) * 5, 0, 100), // rounded to nearest 5: avoid false precision
    status: 'PROTOTYPE ESTIMATE',
    factors: [...factors, ...notScored],
    disclaimer,
  };
}
