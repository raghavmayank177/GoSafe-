export class HttpError extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
}
export class ProviderError extends Error {
  constructor(provider, message) {
    super(message);
    this.provider = provider;
  }
}
