import { config } from './config.js';
import { openDb } from './db.js';
const db = openDb(config.dbPath);
db.close();
console.log(`Database ready at ${config.dbPath}`);
